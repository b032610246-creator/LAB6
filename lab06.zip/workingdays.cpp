#include <iostream>
using namespace std;

int getYear();    
bool isLeap(int year);   

int main() {
    int year;
    bool status;

    year = getYear();   
    status = isLeap(year);  

    return 0;
}

// Function Definition
int getYear() {
    int year; 

    cout << "Enter year: ";
    cin >> year;

    return year; 
}

// Function Definition
bool isLeap(int year) {
    bool status;  

    if (year % 4 == 0)
        status = true;
    else
        status = false;

    return status;
}